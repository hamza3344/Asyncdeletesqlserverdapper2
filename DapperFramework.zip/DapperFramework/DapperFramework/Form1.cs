﻿
using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DapperFramework
{
    public partial class Form1 : Form
    {
        string connection = "Data Source=DESKTOP-R94LU0S\\SQLEXPRESS;Initial Catalog=formsimple;Integrated Security=True;";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void btninsert_Click(object sender, EventArgs e)
        {
            
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            
        }

        private async void btndelete_Click(object sender, EventArgs e)
        {
             using(SqlConnection connect=new SqlConnection(connection))
            {
                await connect.OpenAsync();
                await connect.ExecuteAsync($"DELETE FROM mytable WHERE id='{txtid.Text}'");
            }
        }
    }
}
